package com.mobdeve.s13.s11.group29.mp;

import com.google.firebase.messaging.FirebaseMessagingService;

public class PushNotifications extends FirebaseMessagingService {
}
