package com.mobdeve.s11.s13.group29.mp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvList;
    private RecyclerView.LayoutManager rvManager;
    private Adapter adapter;
    private FloatingActionButton fab;
    private ArrayList<SleepRecord> dataList;
    private final String ACTIVITY_ADD = "ACTIVITY_ADD";

    private ActivityResultLauncher sleepLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent intent = result.getData();
                    String sleepRecordConfirm = intent.getStringExtra(SleepRecordActivity.ADD_RECORD);
                    if(!sleepRecordConfirm.equals("CANCELLED")){ // means successful and complete entry
                        dataList.add(0, new SleepRecord(R.drawable.sleep_record, "Rey Delima", tweet, 0, R.drawable.pochita, new CustomDate()));
                        //adapter.notifyItemChanged(0);
                        //adapter.notifyItemRangeChanged(0,adapter.getItemCount());
                    //}
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRecyclerView();
    }
    private void initRecyclerView(){
        //reference recyclerview
        this.rvList = findViewById(R.id.rv_list);

        //initialize layout manager
        this.rvManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        this.rvList.setLayoutManager(this.rvManager);

        //initialize adapter
        this.dataList = new ArrayList<SleepRecord>();
        //this.adapter = new Adapter(this.dataList);
        //this.rvList.setAdapter(this.adapter);
        addRecord();

        SnapHelper sh = new PagerSnapHelper();
        sh.attachToRecyclerView(this.rvList);
    }
    private void addRecord(){
        this.fab =findViewById(R.id.fab_add);
        this.fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(MainActivity.this, SleepRecordActivity.class);
                //sleepLauncher.launch(i);
                startActivity(i);
            }
        });
    }

}