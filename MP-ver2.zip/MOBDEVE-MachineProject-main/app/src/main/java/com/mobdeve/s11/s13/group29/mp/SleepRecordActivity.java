package com.mobdeve.s11.s13.group29.mp;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class SleepRecordActivity extends AppCompatActivity {
    public static final String ADD_RECORD = "ADD_RECORD";
    public static final String CANCELLED = "CANCELLED";

    public static final String FROM_DATE = "FROM_DATE";
    public static final String TO_DATE = "TO_DATE";
    public static final String FROM_TIME = "FROM_TIME";
    public static final String TO_TIME = "TO_TIME";

    private FloatingActionButton btnRecord;
    private TextView txtRecord;
    private boolean recordStarted = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Please note the layout for this activity is provided
        setContentView(R.layout.activity_record);

        this.btnRecord=findViewById(R.id.btnRecord);
        this.txtRecord=findViewById(R.id.txtRecord);

        this.btnRecord.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(recordStarted){
                    btnRecord.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.sleep_off));
                    btnRecord.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#7d63eb")));
                    txtRecord.setText(R.string.sleepText);
                    recordStarted = false;
                }
                else{
                    btnRecord.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.sleep_on));
                    btnRecord.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#fccf65")));
                    txtRecord.setText(R.string.wakeUpText);
                    recordStarted = true;
                }
            }
        });
    }
}
