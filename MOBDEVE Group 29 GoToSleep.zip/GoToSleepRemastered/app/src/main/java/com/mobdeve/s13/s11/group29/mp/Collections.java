package com.mobdeve.s13.s11.group29.mp;

public enum Collections {
    users,
    sleeprecords
}
