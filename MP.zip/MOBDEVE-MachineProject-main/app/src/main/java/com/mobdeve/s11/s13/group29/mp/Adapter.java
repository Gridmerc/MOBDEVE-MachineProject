package com.mobdeve.s11.s13.group29.mp;

public class Adapter {
}
