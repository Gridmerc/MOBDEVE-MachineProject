package com.mobdeve.s11.s13.group29.mp;

public class SleepRecord {

    private String days, fromTime, toTime;

    public SleepRecord(String days, String fromTime, String toTime){
        this.days = days;
        this.fromTime = fromTime;
        this.toTime = toTime;
    }

    public String getDays(){ return this.days;}
    public String getFromTime(){ return this.fromTime;}
    public String getToTime(){ return this.fromTime;}
}
