package com.mobdeve.s11.s13.group29.mp;

public class SleepRecord {

    private String fromDate, toDate, fromTime, toTime;
    private int imgId;

    public SleepRecord(int imgId, String fromDate, String toDate, String fromTime, String toTime){
        this.imgId = imgId;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.fromTime = fromTime;
        this.toTime = toTime;
    }

    public int getImgId(){ return this.imgId;}
    public String getFromDate(){ return this.fromDate;}
    public String getToDate(){ return this.toDate;}
    public String getFromTime(){ return this.fromTime;}
    public String getToTime(){ return this.toTime;}
}
