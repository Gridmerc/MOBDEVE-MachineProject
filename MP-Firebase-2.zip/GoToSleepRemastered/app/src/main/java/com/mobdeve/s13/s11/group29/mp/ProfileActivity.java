package com.mobdeve.s13.s11.group29.mp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        this.initComponents();
        this.initFirebase();
    }

    private void initComponents() {
        this.pbProfile = findViewById(R.id.pb_profile);
        this.tvWelcome = findViewById(R.id.tv_welcome);
    }

    private void initFirebase() {
        // Let ProgressBar appear
        this.pbProfile.setVisibility(View.VISIBLE);

        // Get instance of Firebase Authentication
        this.mAuth = FirebaseAuth.getInstance();

        // Get the current user from Firebase
        this.mUser = this.mAuth.getCurrentUser();
        this.userID = this.mUser.getUid();

        // Get the Realtime Database from Firebase
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference(Collections.users.name());

        // Acquire information on the current user
        databaseReference.child(this.userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pbProfile.setVisibility(View.GONE);

                String name = snapshot.child("name").getValue().toString();
                tvWelcome.setText("Welcome " + name + "!");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                pbProfile.setVisibility(View.GONE);
            }
        });
    }

    // Attributes
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private ProgressBar pbProfile;
    private String userID;
    private TextView tvWelcome;
}