package com.mobdeve.s11.s13.group29.mp;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SleepRecordActivity extends AppCompatActivity {
    public static final String ADD_RECORD = "ADD_RECORD";
    public static final String CANCELLED = "CANCELLED";

    public static final String FROM_DATE = "FROM_DATE";
    public static final String TO_DATE = "TO_DATE";
    public static final String FROM_TIME = "FROM_TIME";
    public static final String TO_TIME = "TO_TIME";

    private static final String TAG = "MyActivity";

    private FloatingActionButton btnRecord;
    private TextView txtRecord;
    private boolean recordStarted = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Please note the layout for this activity is provided
        setContentView(R.layout.activity_record);

        this.btnRecord=findViewById(R.id.btnRecord);
        this.txtRecord=findViewById(R.id.txtRecord);

        this.btnRecord.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent();

                if(recordStarted){
                    btnRecord.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.sleep_off));
                    btnRecord.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#7d63eb")));
                    txtRecord.setText(R.string.sleepText);
                    recordStarted = false;

                    Date currTime = Calendar.getInstance().getTime();
                    DateFormat timeFormat = new SimpleDateFormat("hh:mm:ss");
                    DateFormat dateFormat = new SimpleDateFormat("mm/dd");
                    String sTime = timeFormat.format(currTime);
                    String dTime = dateFormat.format(currTime);

                    i.putExtra(TO_TIME, sTime);
                    i.putExtra(TO_DATE, dTime);
                    i.putExtra(ADD_RECORD, "ADD_RECORD");
                    setResult(Activity.RESULT_OK, i);
                    finish();
                }
                else{
                    btnRecord.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.sleep_on));
                    btnRecord.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#fccf65")));
                    txtRecord.setText(R.string.wakeUpText);

                    Date currTime = Calendar.getInstance().getTime();
                    DateFormat timeFormat = new SimpleDateFormat("hh:mm:ss");
                    DateFormat dateFormat = new SimpleDateFormat("mm/dd");
                    String sTime = timeFormat.format(currTime);
                    String dTime = dateFormat.format(currTime);

                    i.putExtra(FROM_TIME, sTime);
                    i.putExtra(FROM_DATE, dTime);

                    //Log.i(TAG, sTime);
                    //Log.i(TAG, dTime);
                    //System.out.println(sTime);
                    //System.out.println(dTime);

                    recordStarted = true;
                }
            }
        });
    }
}
