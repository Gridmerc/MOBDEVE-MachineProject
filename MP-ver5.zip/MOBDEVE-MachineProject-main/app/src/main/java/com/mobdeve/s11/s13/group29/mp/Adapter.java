package com.mobdeve.s11.s13.group29.mp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<SleepRecordHolder> {

    public static final String KEY_IMG = "KEY_IMG";
    public static final String KEY_FROM_TIME = "KEY_FROM_TIME";
    public static final String KEY_TO_TIME = "KEY_TO_TIME";
    public static final String KEY_FROM_DATE= "KEY_FROM_DATE";
    public static final String KEY_TO_DATE = "KEY_TO_DATE";


    private ArrayList<SleepRecord> dataList;

    public Adapter(ArrayList<SleepRecord> dataList){
        this.dataList= dataList;
    }
    @NonNull
    @NotNull
    @Override
    public SleepRecordHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.template_record, parent, false);

        SleepRecordHolder sleepRecordHolder = new SleepRecordHolder(view);

        sleepRecordHolder.setSleepRecordHolderOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), SleepRecordActivity.class);
                i.putExtra(KEY_IMG, dataList.get(sleepRecordHolder.getBindingAdapterPosition()).getImgId());
                i.putExtra(KEY_FROM_DATE, dataList.get(sleepRecordHolder.getBindingAdapterPosition()).getFromDate());
                i.putExtra(KEY_TO_DATE, dataList.get(sleepRecordHolder.getBindingAdapterPosition()).getToDate());
                i.putExtra(KEY_FROM_TIME, dataList.get(sleepRecordHolder.getBindingAdapterPosition()).getFromTime());
                i.putExtra(KEY_TO_TIME, dataList.get(sleepRecordHolder.getBindingAdapterPosition()).getToTime());
                v.getContext().startActivity(i);
            }
        });
        //return custom viewholder
        return sleepRecordHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull SleepRecordHolder holder, int position) {
        holder.setImg(this.dataList.get(position).getImgId());
        holder.setTxtDateFrom(this.dataList.get(position).getFromDate());
        holder.setTxtDateTo(this.dataList.get(position).getToDate());
        holder.setTxtTimeFrom(this.dataList.get(position).getFromTime());
        holder.setTxtTimeTo(this.dataList.get(position).getToTime());

    }

    @Override
    public int getItemCount() {
        return this.dataList.size();
    }
}
