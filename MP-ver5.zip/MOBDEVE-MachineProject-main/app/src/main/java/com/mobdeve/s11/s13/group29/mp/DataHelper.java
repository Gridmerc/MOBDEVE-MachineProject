package com.mobdeve.s11.s13.group29.mp;

import java.util.ArrayList;

public class DataHelper {
    public static ArrayList<SleepRecord> loadSleepRecordData() {
        ArrayList<SleepRecord> data = new ArrayList<SleepRecord>();

        data.add(new SleepRecord(R.drawable.sleep_record,
                "08/24", "08/25",
                "22:00:44", "08:15:32"));
        return data;
    }
}
