package com.mobdeve.s11.s13.group29.mp;


import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;


public class SleepRecordHolder extends RecyclerView.ViewHolder {

    private ImageView imgIconSleepRecord;
    private TextView txtDateFrom;
    private TextView txtDateTo;
    private TextView txtTimeFrom;
    private TextView txtTimeTo;
    private LinearLayout llEntry;
    public SleepRecordHolder(@NonNull @NotNull View itemView) {
        super(itemView);

        this.imgIconSleepRecord = itemView.findViewById(R.id.imgIconSleepRecord);
        this.txtDateFrom = itemView.findViewById(R.id.txtDateFrom);
        this.txtDateTo = itemView.findViewById(R.id.txtDateTo);
        this.txtTimeFrom = itemView.findViewById(R.id.txtTimeFrom);
        this.txtTimeTo = itemView.findViewById(R.id.txtTimeTo);
        this.llEntry = itemView.findViewById(R.id.ll_entry);
    }

    public void setImg(int img){
        this.imgIconSleepRecord.setImageResource(img);
    }
    public void setTxtDateFrom(String s){
        this.txtDateFrom.setText(s);
    }
    public void setTxtDateTo(String s){
        this.txtDateTo.setText(s);
    }
    public void setTxtTimeFrom(String s){
        this.txtTimeFrom.setText(s);
    }
    public void setTxtTimeTo(String s){
        this.txtTimeTo.setText(s);
    }
    /*
    public void setTvDate(CustomDate date){
        this.tvDate.setText(date.toStringNoYear());
    }
    public void setTvTweet(String tweet){
        this.tvTweet.setText(tweet);
    }

    */
    public void setSleepRecordHolderOnClickListener(View.OnClickListener onClickListener){
        this.llEntry.setOnClickListener(onClickListener);
    }
}

