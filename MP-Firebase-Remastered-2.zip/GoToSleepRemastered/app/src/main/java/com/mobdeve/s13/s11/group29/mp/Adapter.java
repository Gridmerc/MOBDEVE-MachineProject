package com.mobdeve.s13.s11.group29.mp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.NotNull;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<SleepRecordHolder>{
    private ArrayList<SleepRecord> dataList;
    DatabaseReference databaseReference;

    public Adapter(ArrayList<SleepRecord> dataList){

        this.dataList= dataList;
        databaseReference  = FirebaseDatabase.getInstance().getReference(Collections.users.name());
        //databaseReference.child(FirebaseAuth.getInstance().getUid()).child(Collections.sleeprecords.name())
    }
    @NonNull
    @NotNull
    @Override
    public SleepRecordHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.template_record, parent, false);

        SleepRecordHolder sleepRecordHolder = new SleepRecordHolder(view);

        sleepRecordHolder.setFabDeleteOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Implement delete button here

                //FirebaseDatabase.getInstance().getReference().child("sleeprecords").child(getRef(position).getKey().removeValue());
                // FirebaseDatabase.getInstance().getReference().child("sleeprecords").child(getRef(position).getKey().removeValue());
                //DatabaseReference key = databaseReference.child(FirebaseAuth.getInstance().getUid()).child(Collections.sleeprecords.name());



                //FirebaseDatabase.getInstance().getReference().child("sleeprecords").child(key).remove();
                System.out.println("clicked");
                //System.out.println(key);
            }
        });
        //return custom viewholder
        return sleepRecordHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull SleepRecordHolder holder, int position) {
        holder.setImg(this.dataList.get(position).getImgId());
        holder.setTxtDateFrom(this.dataList.get(position).getFromDate());
        holder.setTxtDateTo(this.dataList.get(position).getToDate());
        holder.setTxtTimeFrom(this.dataList.get(position).getFromTime());
        holder.setTxtTimeTo(this.dataList.get(position).getToTime());

    }

    @Override
    public int getItemCount() {
        return this.dataList.size();
    }
}
